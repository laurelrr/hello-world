# helloworld
Testing initial repository with basic hello world function
November 2, 2020


# # Installation
Run the following to install:
```python
   pip install helloworld
```

# Devloping Hello world
To install hellowrold, along with the tools to develop and run tests, run the following in your virtualenv:
```bash
$ pip install -e .[dev]
```


# # Usage
```python
from helloworld import say_hello

# generate "Hello, World!"
say_hello()

# generate "Hello, Everybody!"
say_hello("Everybody")
```

# publish on pypi and github
